import UserTable from "src/components/tables/UsersTable"


const Table = () => {
  return (
    <div className="p-6">
      <UserTable/>
    </div>
  )
}

export default Table
