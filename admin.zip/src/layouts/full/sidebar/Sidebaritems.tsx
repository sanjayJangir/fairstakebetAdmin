const SidebarContent = [
  {
    heading: 'Main',
    children: [
      {
        id: 1,
        name: 'Dashboard',
        icon: 'mdi:view-dashboard', // Changed icon to dashboard
        url: '/dashboard',
      },
      // ... other menu items
    ],
  },
  // ... other sections
];

export default SidebarContent;